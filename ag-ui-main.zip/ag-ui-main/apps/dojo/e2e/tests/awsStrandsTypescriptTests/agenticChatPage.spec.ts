import { agenticChatPageEventTrace } from "./agenticChatPage.event-trace";
import { test, expect } from "../../event-trace-test";
import { AgenticChatPage } from "../../featurePages/AgenticChatPage";

test("[StrandsTS] Agentic Chat sends and receives a message", async ({
  page,
  eventTrace,
}) => {
  await page.goto("/aws-strands-typescript/feature/agentic_chat", {
    waitUntil: "networkidle",
  });

  const chat = new AgenticChatPage(page);

  await chat.openChat();
  await expect(chat.agentGreeting).toBeVisible();
  await chat.sendMessage("Hi, I am duaa");

  await chat.assertUserMessageVisible("Hi, I am duaa");
  await chat.assertAgentReplyVisible(/Hello duaa/i);

  await eventTrace.expectJourney(
    agenticChatPageEventTrace.agenticChatSendsAndReceivesAMessage,
  );
});

test("[StrandsTS] Agentic Chat changes background on message and reset", async ({
  page,
  eventTrace,
}) => {
  await page.goto("/aws-strands-typescript/feature/agentic_chat", {
    waitUntil: "networkidle",
  });

  const chat = new AgenticChatPage(page);

  await chat.openChat();
  await expect(chat.agentGreeting).toBeVisible();

  const backgroundContainer = page.locator(
    '[data-testid="background-container"]',
  );
  const getBackground = () =>
    backgroundContainer.evaluate((el) => el.style.background);
  const initialBackground = await getBackground();

  await chat.sendMessage("Hi change the background color to blue");
  await chat.assertUserMessageVisible("Hi change the background color to blue");

  await expect.poll(getBackground).not.toBe(initialBackground);
  const backgroundAfterBlue = await getBackground();

  await chat.sendMessage("Hi change the background color to pink");
  await chat.assertUserMessageVisible("Hi change the background color to pink");

  await expect.poll(getBackground).not.toBe(backgroundAfterBlue);

  await eventTrace.expectJourney(
    agenticChatPageEventTrace.agenticChatChangesBackgroundOnMessageAndReset,
  );
});

test("[StrandsTS] Agentic Chat retains memory of user messages during a conversation", async ({
  page,
  eventTrace,
}) => {
  await page.goto("/aws-strands-typescript/feature/agentic_chat", {
    waitUntil: "networkidle",
  });

  const chat = new AgenticChatPage(page);
  await chat.openChat();
  await chat.agentGreeting.click();

  await chat.sendMessage("Hey there");
  await chat.assertUserMessageVisible("Hey there");
  await chat.assertAgentReplyVisible(/Hello! How can I assist you today\?/);

  const favFruit = "Mango";
  await chat.sendMessage(`My favorite fruit is ${favFruit}`);
  await chat.assertUserMessageVisible(`My favorite fruit is ${favFruit}`);
  await chat.assertAgentReplyVisible(/Mango is a wonderful tropical fruit/);

  await chat.sendMessage("and I love listening to Kaavish");
  await chat.assertUserMessageVisible("and I love listening to Kaavish");
  await chat.assertAgentReplyVisible(/Kaavish is a wonderful musical group/);

  await chat.sendMessage("tell me an interesting fact about Moon");
  await chat.assertUserMessageVisible("tell me an interesting fact about Moon");
  await chat.assertAgentReplyVisible(
    /The Moon is Earth's only natural satellite/,
  );

  await chat.sendMessage("Can you remind me what my favorite fruit is?");
  await chat.assertUserMessageVisible(
    "Can you remind me what my favorite fruit is?",
  );
  await chat.assertAgentReplyVisible(/Your favorite fruit is Mango!/);

  await eventTrace.expectJourney(
    agenticChatPageEventTrace.agenticChatRetainsMemoryOfUserMessagesDuringAConversation,
  );
});
